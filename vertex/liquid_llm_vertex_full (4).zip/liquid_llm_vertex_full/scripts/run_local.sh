#!/usr/bin/env bash
set -euo pipefail
python -m trainer.entrypoint "$@"
