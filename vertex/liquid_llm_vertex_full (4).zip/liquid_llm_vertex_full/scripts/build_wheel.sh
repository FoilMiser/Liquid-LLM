#!/usr/bin/env bash
set -euo pipefail
python -m pip install --upgrade build
python -m build
